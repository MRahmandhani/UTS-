<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo "Muhammad Rahmandhani"; ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>

	<!-- header -->
	<div class="medsos">
		<div class="container">
			<ul>
				<li><a href="#"><i class="fab fa-facebook"></i></a></li>
				<li><a href="#"><i class="fab fa-instagram"></i></a></li>
				<li><a href="#"><i class="fab fa-youtube"></i></a></li>
			</ul>
		</div>
	</div>
	<header>
		<div class="container">
		<h1><a href="index.php"><?php echo "Fani SHOP"; ?></a></h1>
		<ul>
			<li class="active"><a href="index.php"><?php echo "HOME"; ?></a></li>
			<li><a href="about.php"><?php echo "PRODUCT"; ?></a></li>
		</ul>
		</div>
	</header>

	<!-- content -->
	<section class="content">
		<div class="container">
			<!-- Your existing HTML content here -->
		</div>
	</section>

	<!-- footer -->
	<footer>
		<div class="container">
			<small>Copyright &copy; 2024 - Muhammad Rahmandhani.</small>
		</div>
	</footer>
</body>
</html> 