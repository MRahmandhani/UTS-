<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Muhammad Rahmandhani</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>

	<!-- header -->
	<div class="medsos">
		<div class="container">
			<ul>
				<li><a href="#"><i class="fab fa-facebook"></i></a></li>
				<li><a href="#"><i class="fab fa-instagram"></i></a></li>
				<li><a href="#"><i class="fab fa-youtube"></i></a></li>
			</ul>
		</div>
	</div>
	<header>
		<div class="container">
			<h1><a href="index.php">Toko Baju</a></h1>
			<ul>
				<li class="active"><a href="index.php">HOME</a></li>
				<li><a href="about.php">PRODUCT</a></li>
				<li><a href="contact.php">CONTACT</a></li>
			</ul>
		</div>
	</header>

	<!-- banner -->
	<section class="banner">
		<h2>WELCOME TO MY WEBSITE</h2>
	</section>

	<!-- about -->
	<section class="about">
		<div class="container">
			<h3>ABOUT</h3>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <strong>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</strong> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
		</div>
	</section>

	<!-- products -->
	<section class="products">
		<div class="container">
			<h3>PRODUK KAMI</h3>
			<div class="product-list">
				<div class="product-item">
					<img src="img/sepatu-nike.jpg" alt="Sepatu Sport">
					<h4>Sepatu Sport Nike</h4>
					<p class="price">Rp 1.500.000</p>
					<a href="https://wa.me/628xxxxxxxxxx?text=Saya%20ingin%20membeli%20Sepatu%20Sport%20Nike" class="buy-button">
						<i class="fab fa-whatsapp"></i> Beli via WhatsApp
					</a>
				</div>
				<div class="product-item">
					<img src="img/tas-adidas.jpg" alt="Tas Ransel">
					<h4>Tas Ransel Adidas</h4>
					<p class="price">Rp 800.000</p>
					<a href="https://wa.me/628xxxxxxxxxx?text=Saya%20ingin%20membeli%20Tas%20Ransel%20Adidas" class="buy-button">
						<i class="fab fa-whatsapp"></i> Beli via WhatsApp
					</a>
				</div>
				<div class="product-item">
					<img src="img/jam-casio.jpg" alt="Jam Tangan">
					<h4>Jam Tangan Casio</h4>
					<p class="price">Rp 2.500.000</p>
					<a href="https://wa.me/628xxxxxxxxxx?text=Saya%20ingin%20membeli%20Jam%20Tangan%20Casio" class="buy-button">
						<i class="fab fa-whatsapp"></i> Beli via WhatsApp
					</a>
				</div>
			</div>
		</div>
	</section>

	<!-- footer -->
	<footer>
		<div class="container">
			<small> Copyright &copy; <?php echo date("Y"); ?> - Muhammad Rahmandhani, All Rights Reserved.</small>
		</div>
	</footer>
</body>
</html